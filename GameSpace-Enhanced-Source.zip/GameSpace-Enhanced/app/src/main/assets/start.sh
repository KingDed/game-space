#!/system/bin/sh
set -e

PKG="com.diffmemorymas.gamemode.pro"
SERVER_CLASS="com.diffmemorymas.gamemode.pro.server.Server"
BASE=/data/local/tmp/adbwifi
SUPERVISOR="$BASE/supervise.sh"

APK=$(pm path "$PKG" 2>/dev/null | sed -n 's/^package://p' | head -n1)
if [ -z "$APK" ]; then
  echo "Apk not found $PKG"
  exit 1
fi

mkdir -p "$BASE"
chmod 755 "$BASE" 2>/dev/null || true
cd "$BASE"

echo "APK       : $APK"
echo "Run on: uid $(id -u) ($(id -un 2>/dev/null))"

SDK=$(getprop ro.build.version.sdk)
echo "Android SDK: $SDK"

if [ "$SDK" -ge 31 ] 2>/dev/null; then
  echo "— Close phantom process killer (Android 12+) —"
  settings put global settings_enable_monitor_phantom_procs false 2>/dev/null \
    && echo "  settings_enable_monitor_phantom_procs = false" \
    || echo "  Set settings failed"

  device_config put activity_manager max_phantom_processes 2147483647 2>/dev/null \
    && echo "  max_phantom_processes = no limit" \
    || echo "  Set device_config failed"

  device_config set_sync_disabled_for_tests persistent 2>/dev/null \
    && echo "  Lock device_config" \
    || true
fi

echo -1000 > /proc/self/oom_score_adj 2>/dev/null || true


pkill -f "supervise.sh" 2>/dev/null || true
pkill -f "$SERVER_CLASS" 2>/dev/null || true
sleep 1

cat > "$SUPERVISOR" <<EOF
#!/system/bin/sh
BASE="$BASE"
PKG="$PKG"
SERVER_CLASS="$SERVER_CLASS"

while true; do
  APK=\$(pm path "\$PKG" 2>/dev/null | sed -n 's/^package://p' | head -n1)
  if [ -z "\$APK" ]; then
    echo "[supervisor] APK not found — wait 10s" >> "\$BASE/server.log"
    sleep 10
    continue
  fi

  echo "[supervisor] release helper \$(date)" >> "\$BASE/server.log"

  ANDROID_DATA="\$BASE" CLASSPATH="\$APK" \\
  app_process -Djava.class.path="\$APK" /system/bin \\
    --nice-name=adbwifi_server "\$SERVER_CLASS" "\$PKG" >> "\$BASE/server.log" 2>&1

  CODE=\$?
  echo "[supervisor] helper end exit=\$CODE —Restart in 2sิ" >> "\$BASE/server.log"
  sleep 2
done
EOF

chmod 755 "$SUPERVISOR"

if command -v setsid > /dev/null 2>&1; then
  setsid nohup sh "$SUPERVISOR" > /dev/null 2>&1 &
  echo "— release supervisor with setsid —"
else
  nohup sh "$SUPERVISOR" > /dev/null 2>&1 &
  echo "— release supervisor with nohup (no setsid) —"
fi

sleep 4

if pgrep -f "$SERVER_CLASS" > /dev/null 2>&1; then
  echo "helper working"
  echo "view log : adb shell tail -f $BASE/server.log"
  echo "stop   : adb shell pkill -f supervise.sh && adb shell pkill -f $SERVER_CLASS"
else
  echo "helper no — log:"
  tail -n 40 "$BASE/server.log" 2>/dev/null
  exit 1
fi
