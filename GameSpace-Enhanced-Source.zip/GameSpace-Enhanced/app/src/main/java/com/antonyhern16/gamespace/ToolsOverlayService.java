package com.antonyhern16.gamespace;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/**
 * Optional floating Game Tools panel. Starts only when the user turns it on and has granted
 * "display over other apps". A small handle on the screen edge expands into a panel; refresh runs
 * only while the panel is open. Stop it from the notification, the panel, or the app.
 */
public class ToolsOverlayService extends Service {
    static final String ACTION_STOP = "com.antonyhern16.gamespace.STOP_OVERLAY";
    private static final String CHANNEL = "gs_overlay";
    private static final int NOTIF_ID = 42;
    private static volatile boolean running = false;

    static boolean isRunning() { return running; }

    private WindowManager wm;
    private LinearLayout handle;
    private LinearLayout panel;
    private TextView stats;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            h.postDelayed(this, 2000);
        }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        goForeground();
        try {
            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            buildHandle();
            running = true;
        } catch (RuntimeException e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Game Tools panel", NotificationManager.IMPORTANCE_LOW));
        }
        PendingIntent stop = PendingIntent.getService(this, 1,
            new Intent(this, ToolsOverlayService.class).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Game Tools panel is on")
            .setContentText("Tap Turn off to remove the floating handle")
            .addAction(new Notification.Action.Builder(null, "Turn off", stop).build())
            .setOngoing(true)
            .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTIF_ID, n);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private WindowManager.LayoutParams lp(int w, int hgt, int gravity) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, hgt,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        p.gravity = gravity;
        return p;
    }

    private GradientDrawable bg(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), Color.parseColor("#FF2D4B"));
        return g;
    }

    private TextView button(String label, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(48));
        t.setBackground(bg(Color.parseColor("#22222A"), 10));
        t.setContentDescription(label);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }

    private void buildHandle() {
        handle = new LinearLayout(this);
        handle.setBackground(bg(Color.parseColor("#E60B0B0E"), 12));
        TextView t = new TextView(this);
        t.setText("GS");
        t.setTextColor(Color.parseColor("#FF2D4B"));
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        handle.addView(t, new LinearLayout.LayoutParams(dp(44), dp(48)));
        handle.setContentDescription("Open Game Tools panel");
        handle.setOnClickListener(v -> showPanel());
        wm.addView(handle, lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.CENTER_VERTICAL));
    }

    private void showPanel() {
        if (panel != null) return;
        handle.setVisibility(View.GONE);
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));
        panel.setBackground(bg(Color.parseColor("#F20B0B0E"), 16));
        TextView title = new TextView(this);
        title.setText("GAME TOOLS");
        title.setTextColor(Color.parseColor("#FF2D4B"));
        title.setTextSize(12);
        panel.addView(title);
        stats = new TextView(this);
        stats.setTextColor(Color.WHITE);
        stats.setTextSize(13);
        stats.setPadding(0, dp(6), 0, dp(6));
        panel.addView(stats);
        panel.addView(button("Volume up", v -> volume(AudioManager.ADJUST_RAISE)));
        panel.addView(button("Volume down", v -> volume(AudioManager.ADJUST_LOWER)));
        panel.addView(button("Open Game Space", v -> {
            Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(i);
            hidePanel();
        }));
        panel.addView(button("Close panel", v -> hidePanel()));
        panel.addView(button("Turn panel off", v -> stopSelf()));
        wm.addView(panel, lp(dp(240), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.CENTER_VERTICAL));
        refresh();
        h.postDelayed(tick, 2000);
    }

    private void hidePanel() {
        h.removeCallbacks(tick);
        if (panel != null) {
            try { wm.removeView(panel); } catch (RuntimeException ignored) {}
            panel = null;
        }
        if (handle != null) handle.setVisibility(View.VISIBLE);
    }

    private void volume(int dir) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (am != null) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
    }

    private void refresh() {
        if (stats == null) return;
        JSONObject s = SystemInfo.snapshot(this);
        String temp = s.isNull("tempC") ? "n/a" : s.optDouble("tempC") + " °C";
        String thermal = s.isNull("thermal") ? "n/a" : s.optString("thermal");
        stats.setText("RAM free  " + (s.optLong("freeMb", -1) / 1024.0 > 0 ? String.format(java.util.Locale.US, "%.1f GB", s.optLong("freeMb") / 1024.0) : "n/a")
            + "\nBattery  " + s.optInt("battery", -1) + "%" + (s.optBoolean("charging") ? " (charging)" : "")
            + "\nBattery temp  " + temp
            + "\nThermal  " + thermal
            + "\nNetwork  " + s.optString("network", "n/a"));
    }

    @Override public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        for (View v : new View[]{panel, handle}) {
            if (v != null) { try { wm.removeView(v); } catch (RuntimeException ignored) {} }
        }
        panel = null; handle = null;
        running = false;
        super.onDestroy();
    }
}
