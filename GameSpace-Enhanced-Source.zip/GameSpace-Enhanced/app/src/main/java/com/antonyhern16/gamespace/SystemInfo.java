package com.antonyhern16.gamespace;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.os.StatFs;

import org.json.JSONException;
import org.json.JSONObject;

/** Reads only values Android legitimately exposes. Unavailable values are reported as null / -1, never invented. */
final class SystemInfo {
    private SystemInfo() {}

    static String[] THERMAL = {"none", "light", "moderate", "severe", "critical", "emergency", "shutdown"};

    static long freeMb(Context c) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return -1;
        am.getMemoryInfo(mi);
        return mi.availMem / 1048576L;
    }

    static JSONObject snapshot(Context c) {
        JSONObject o = new JSONObject();
        try {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                am.getMemoryInfo(mi);
                o.put("freeMb", mi.availMem / 1048576L);
                o.put("totalMb", mi.totalMem / 1048576L);
                o.put("lowMemory", mi.lowMemory);
            }

            Intent bi = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bi != null) {
                int lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                int st = bi.getIntExtra(BatteryManager.EXTRA_STATUS, 0);
                int temp = bi.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
                o.put("battery", (lvl >= 0 && scale > 0) ? lvl * 100 / scale : -1);
                o.put("charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL);
                if (temp != Integer.MIN_VALUE && temp > 0) o.put("tempC", temp / 10.0); else o.put("tempC", JSONObject.NULL);
            }

            if (Build.VERSION.SDK_INT >= 29) {
                PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
                int t = pm == null ? -1 : pm.getCurrentThermalStatus();
                o.put("thermal", (t >= 0 && t < THERMAL.length) ? THERMAL[t] : JSONObject.NULL);
            } else {
                o.put("thermal", JSONObject.NULL);
            }

            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            o.put("storageFreeGb", round1(fs.getAvailableBytes() / 1073741824.0));
            o.put("storageTotalGb", round1(fs.getTotalBytes() / 1073741824.0));

            o.put("network", network(c));
            o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            o.put("android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
            o.put("cores", Runtime.getRuntime().availableProcessors());
        } catch (JSONException | RuntimeException ignored) {
            // Return whatever was collected; the UI shows "n/a" for missing keys.
        }
        return o;
    }

    private static double round1(double v) { return Math.round(v * 10.0) / 10.0; }

    private static String network(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return "unknown";
            Network n = cm.getActiveNetwork();
            if (n == null) return "offline";
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            if (nc == null) return "offline";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi-Fi";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "Cellular";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            return "online";
        } catch (RuntimeException e) {
            return "unknown";
        }
    }
}
