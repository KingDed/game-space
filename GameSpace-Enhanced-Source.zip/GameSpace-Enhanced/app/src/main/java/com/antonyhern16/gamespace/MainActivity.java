package com.antonyhern16.gamespace;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.util.LruCache;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Hosts the Game Space panel (assets/panel.html) and gives it a small, honest native bridge. */
public class MainActivity extends Activity {
    private WebView web;
    private int prevFilter = -1;
    private final LruCache<String, String> iconCache = new LruCache<>(120);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0B0B0E"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                // Keep the JS bridge on our own page only; send everything else to the system.
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme()) && u.getPath() != null && u.getPath().startsWith("/android_asset/")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (RuntimeException ignored) {}
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Native");
        setContentView(web);
        web.loadUrl("file:///android_asset/panel.html");
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) { web.onResume(); web.evaluateJavascript("window.gsVisible&&gsVisible(true)", null); }
    }

    @Override protected void onPause() {
        if (web != null) { web.evaluateJavascript("window.gsVisible&&gsVisible(false)", null); web.onPause(); }
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("Native"); web.destroy(); web = null; }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript("window.gsBack?gsBack():false", value -> {
                if (!"true".equals(value)) super.onBackPressed();
            });
        } else super.onBackPressed();
    }

    private Set<String> launchablePackages() {
        Set<String> out = new HashSet<>();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo ri : getPackageManager().queryIntentActivities(q, 0)) out.add(ri.activityInfo.packageName);
        return out;
    }

    private static String bitmapToDataUri(Drawable d) {
        int size = 96;
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        d.setBounds(0, 0, size, size);
        d.draw(c);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 90, bos);
        bmp.recycle();
        return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
    }

    private class Bridge {
        @JavascriptInterface public String stats() {
            return SystemInfo.snapshot(MainActivity.this).toString();
        }

        /** All launchable apps (names only; icons are fetched lazily with icon()). */
        @JavascriptInterface public String apps() {
            JSONArray arr = new JSONArray();
            try {
                PackageManager pm = getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                Set<String> seen = new HashSet<>();
                for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                    JSONObject o = new JSONObject();
                    CharSequence label = ri.loadLabel(pm);
                    o.put("pkg", pkg);
                    o.put("name", label == null ? pkg : label.toString());
                    // Android's own category flag; many games declare it, some do not.
                    boolean game = false;
                    if (Build.VERSION.SDK_INT >= 26) game = ri.activityInfo.applicationInfo.category == ApplicationInfo.CATEGORY_GAME;
                    o.put("game", game);
                    arr.put(o);
                }
            } catch (Exception ignored) {}
            return arr.toString();
        }

        @JavascriptInterface public String icon(String pkg) {
            String hit = iconCache.get(pkg);
            if (hit != null) return hit;
            try {
                String uri = bitmapToDataUri(getPackageManager().getApplicationIcon(pkg));
                iconCache.put(pkg, uri);
                return uri;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface public String appInfo(String pkg) {
            JSONObject o = new JSONObject();
            try {
                PackageInfo pi = getPackageManager().getPackageInfo(pkg, 0);
                o.put("pkg", pkg);
                o.put("version", pi.versionName == null ? "n/a" : pi.versionName);
                o.put("installed", DateFormat.getDateInstance().format(new Date(pi.firstInstallTime)));
                o.put("updated", DateFormat.getDateInstance().format(new Date(pi.lastUpdateTime)));
            } catch (Exception e) {
                try { o.put("error", "Not installed"); } catch (Exception ignored) {}
            }
            return o.toString();
        }

        @JavascriptInterface public String installedGames(String csv) {
            StringBuilder sb = new StringBuilder();
            PackageManager pm = getPackageManager();
            for (String p : csv.split(",")) {
                if (p.isEmpty()) continue;
                try { pm.getPackageInfo(p, 0); sb.append(p).append(','); } catch (Exception ignored) {}
            }
            return sb.toString();
        }

        @JavascriptInterface public String cleanRam(String gamePkg) {
            long before = SystemInfo.freeMb(MainActivity.this);
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            PackageManager pm = getPackageManager();
            int n = 0;
            for (String pkg : launchablePackages()) {
                if (pkg.equals(getPackageName()) || pkg.equals(gamePkg)) continue;
                try {
                    ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                    if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                    if (am != null) { am.killBackgroundProcesses(pkg); n++; }
                } catch (Exception ignored) {}
            }
            try { Thread.sleep(700); } catch (InterruptedException ignored) {}
            return "Asked Android to stop " + n + " background apps. Free RAM " + before + " MB -> "
                + SystemInfo.freeMb(MainActivity.this) + " MB (Android may restart some).";
        }

        @JavascriptInterface public boolean hasDnd() {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            return nm != null && nm.isNotificationPolicyAccessGranted();
        }

        @JavascriptInterface public void openDndAccess() {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }

        @JavascriptInterface public String setDnd(boolean on) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return "Do Not Disturb is not available on this device.";
            if (!nm.isNotificationPolicyAccessGranted()) { openDndAccess(); return "Allow Do Not Disturb access for Game Space, then try again."; }
            if (on) {
                if (prevFilter < 0) prevFilter = nm.getCurrentInterruptionFilter();
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
                return "Do Not Disturb on (priority only).";
            }
            if (prevFilter >= 0) { nm.setInterruptionFilter(prevFilter); prevFilter = -1; }
            return "Do Not Disturb restored.";
        }

        @JavascriptInterface public void setBright(final boolean max) {
            runOnUiThread(() -> {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = max ? 1f : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
                getWindow().setAttributes(lp);
            });
        }

        @JavascriptInterface public void keepAwake(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface public boolean launch(String pkg) {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) return false;
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return true;
            } catch (RuntimeException e) {
                return false;
            }
        }

        // ---- floating Game Tools panel ----
        @JavascriptInterface public boolean hasOverlayPermission() {
            return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(MainActivity.this);
        }

        @JavascriptInterface public void requestOverlayPermission() {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }

        @JavascriptInterface public boolean overlayRunning() { return ToolsOverlayService.isRunning(); }

        @JavascriptInterface public String setOverlay(final boolean on) {
            if (!on) {
                startService(new Intent(MainActivity.this, ToolsOverlayService.class).setAction(ToolsOverlayService.ACTION_STOP));
                return "Floating panel off.";
            }
            if (!hasOverlayPermission()) { requestOverlayPermission(); return "Allow 'Display over other apps' for Game Space, come back, then turn it on again."; }
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7));
            }
            try {
                startForegroundService(new Intent(MainActivity.this, ToolsOverlayService.class));
                return "Floating panel on. Look for the GS handle on the right edge.";
            } catch (RuntimeException e) {
                return "Could not start the floating panel on this device.";
            }
        }

        @JavascriptInterface public void copy(String text) {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("gs", text));
        }
    }
}
