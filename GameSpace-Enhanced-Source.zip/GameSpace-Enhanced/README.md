# GameSpace Enhanced

Dark, red-accent Game Space dashboard (Java + WebView panel, no third-party dependencies).

Tabs: Home, Library (real launcher apps with icons, search, sort, favorites, recents, details sheet),
Profiles (Balanced / Performance / Battery Saver / Custom that change real Game Space behavior),
Performance (RAM, storage, battery, battery temp, thermal status, in-app FPS, ping), Tools (optional
floating panel with volume/battery/thermal; DND, brightness, keep-awake, free RAM), Training, AI, Helper.

Honest limits: no CPU/GPU overclock, no other-app FPS, no CPU/GPU load (Android does not expose them to apps).

## Build
Requires JDK 17, Android SDK (platform 35), Gradle 8.9:

    gradle clean assembleDebug

APK: app/build/outputs/apk/debug/app-debug.apk (CI renames it GameSpace-Enhanced.apk).
Or push to GitHub and run the "Build GameSpace Enhanced APK" workflow.
